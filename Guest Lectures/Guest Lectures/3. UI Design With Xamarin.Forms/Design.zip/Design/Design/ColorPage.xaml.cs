﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Design
{
	public partial class ColorPage : ContentPage
	{
		public ColorPage ()
		{
			InitializeComponent ();
		}
	}
}

