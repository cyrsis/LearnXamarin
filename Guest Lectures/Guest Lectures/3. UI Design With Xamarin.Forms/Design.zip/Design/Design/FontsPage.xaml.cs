﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Design
{
	public partial class FontsPage : ContentPage
	{
		public FontsPage ()
		{
			InitializeComponent ();
		}
	}
}

